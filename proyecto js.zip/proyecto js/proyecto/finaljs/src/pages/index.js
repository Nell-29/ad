export * from"./login/login";
export * from"./dashboard/dashboard";
export* from"./pokemon/pokemon";
