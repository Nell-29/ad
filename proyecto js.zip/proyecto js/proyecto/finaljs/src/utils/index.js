export * from "./axios";
export * from "./cambioColor";
export * from "./dataPokemon";
export * from "./initTemplate";
export * from "./pag";
export * from "./ruta";
export * from "./tipoPoke";