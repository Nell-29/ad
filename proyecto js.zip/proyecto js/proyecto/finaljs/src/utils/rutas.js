
import { initTemplate } from "./initTemplate";
import { PrintLogin } from "../pages/login/login";
export const initControler =(page) => {
    localStorage.getItem("username")?  initTemplate():
     PrintLogin();
}